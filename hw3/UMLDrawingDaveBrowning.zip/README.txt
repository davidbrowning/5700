This is my attempt at a UML drawing program. 

As of right now, unfortunatly only colors represent 
 relationships as I spent too much time trying to 
 work on the relationship factory so I did not have
 sufficient time to work on drawing the specific shapes. 