﻿namespace GuiLayer
{
    partial class ObserverCreationForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.G = new System.Windows.Forms.RadioButton();
            this.ListViewRadioButton = new System.Windows.Forms.RadioButton();
            this.button1 = new System.Windows.Forms.Button();
            this.groupBox1.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.G);
            this.groupBox1.Controls.Add(this.ListViewRadioButton);
            this.groupBox1.Location = new System.Drawing.Point(24, 30);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(596, 122);
            this.groupBox1.TabIndex = 0;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Observer Type";
            // 
            // G
            // 
            this.G.AutoSize = true;
            this.G.Location = new System.Drawing.Point(358, 48);
            this.G.Name = "G";
            this.G.Size = new System.Drawing.Size(108, 21);
            this.G.TabIndex = 1;
            this.G.TabStop = true;
            this.G.Text = "GraphicView";
            this.G.UseVisualStyleBackColor = true;
            // 
            // ListViewRadioButton
            // 
            this.ListViewRadioButton.AutoSize = true;
            this.ListViewRadioButton.Location = new System.Drawing.Point(29, 48);
            this.ListViewRadioButton.Name = "ListViewRadioButton";
            this.ListViewRadioButton.Size = new System.Drawing.Size(80, 21);
            this.ListViewRadioButton.TabIndex = 0;
            this.ListViewRadioButton.TabStop = true;
            this.ListViewRadioButton.Text = "ListView";
            this.ListViewRadioButton.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(474, 170);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Create";
            this.button1.UseVisualStyleBackColor = true;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // ObserverCreationForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(648, 218);
            this.Controls.Add(this.button1);
            this.Controls.Add(this.groupBox1);
            this.Name = "ObserverCreationForm";
            this.Text = "ObserverCreationForm";
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton ListViewRadioButton;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.RadioButton G;
    }
}